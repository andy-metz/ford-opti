﻿

Pour tester le programme
- Lancer Visual C++
- ouvrir la solution ford-opti.sln dans le répertoire ford-opti

Exécuter (F5)

Le programme exécutera Belmman-Ford optimisé sur le graphe dé-commenté dans main.cpp

Pour exécuter sur un autre graphe, commenter les lignes correpondant au graphe en cours et dé-commenter le graphe à tester.


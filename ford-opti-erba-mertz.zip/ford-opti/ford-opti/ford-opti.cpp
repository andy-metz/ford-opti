// opti

#include <string>
#include <iostream>
#include "ford-opti.h"

ostream & operator << (ostream & os, const Vertices_list & vl){
	return os << vl;
}